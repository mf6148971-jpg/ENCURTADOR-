import {PrismaClient} from "@prisma/client"; import bcrypt from "bcryptjs";
const db=new PrismaClient();
async function main(){
 const email=(process.env.ADMIN_EMAIL||"mf8585596@gmail.com").toLowerCase();
 const password=process.env.ADMIN_PASSWORD||"teste123321";
 await db.user.upsert({where:{email},update:{role:"ADMIN",passwordHash:await bcrypt.hash(password,12),name:"Administrador"},create:{email,passwordHash:await bcrypt.hash(password,12),role:"ADMIN",name:"Administrador"}});
 console.log("Admin pronto:",email);
} main().finally(()=>db.$disconnect());
