import Link from "next/link";
export default function Header(){return <header className="header"><div className="container nav"><Link href="/" className="logo">↗ LinkPro</Link><nav><Link href="/login">Entrar</Link><Link href="/register" className="btn small">Criar conta</Link></nav></div></header>}
