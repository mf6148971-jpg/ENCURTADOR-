# LinkPro — encurtador monetizado

Projeto público de encurtador com cadastro, login, links curtos, contabilização de cliques, saldo e painel admin.

## Rodar
1. Node.js 20+
2. PostgreSQL
3. Copie `.env.example` para `.env.local`
4. Preencha `DATABASE_URL` e `NEXTAUTH_SECRET`
5. `npm install`
6. `npx prisma db push`
7. `npm run db:seed`
8. `npm run dev`

Admin de teste:
- e-mail: `mf8585596@gmail.com`
- senha: `teste123321`

## GitHub/Vercel
Suba para GitHub, importe na Vercel e cadastre as variáveis do `.env.local`. Rode `prisma db push` no banco de produção e `npm run db:seed` uma vez.

## Monetização
A página intermediária já tem espaço para anúncios. Antes do lançamento, conecte uma rede de anúncios compatível e implemente antifraude, limites de tráfego, política de uso e regras de saque. Não use tráfego inválido ou automação de cliques.
