import "./globals.css"; import Header from "@/components/Header";
export const metadata={title:"LinkPro — Encurtador monetizado",description:"Encurte links e acompanhe seus ganhos."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="pt-BR"><body><Header/>{children}</body></html>}
