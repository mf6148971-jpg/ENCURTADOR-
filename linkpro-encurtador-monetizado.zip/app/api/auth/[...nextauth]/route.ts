import NextAuth,{NextAuthOptions} from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs"; import {db} from "@/lib/prisma";
export const authOptions:NextAuthOptions={
 session:{strategy:"jwt"},
 providers:[CredentialsProvider({name:"credentials",credentials:{email:{},password:{}},async authorize(c){
  if(!c?.email||!c.password)return null;
  const u=await db.user.findUnique({where:{email:c.email.toLowerCase()}});
  if(!u||!(await bcrypt.compare(c.password,u.passwordHash)))return null;
  return {id:u.id,email:u.email,name:u.name,role:u.role};
 }})],
 callbacks:{
  async jwt({token,user}){if(user)token.role=(user as any).role;return token},
  async session({session,token}){if(session.user){session.user.id=token.sub!;session.user.role=token.role as string}return session}
 },
 secret:process.env.NEXTAUTH_SECRET
};
const h=NextAuth(authOptions); export {h as GET,h as POST};
